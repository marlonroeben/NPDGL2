close all;
e = 1e-2;
e_plotError(e);
title('\epsilon = 1e-2');
figure
e = 1e-3;
e_plotError(e);
title('\epsilon = 1e-3');
figure
e = 1e-4;
e_plotError(e);
title('\epsilon = 1e-4');